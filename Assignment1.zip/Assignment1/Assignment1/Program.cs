﻿using Assignment1.Classes;

Mercedes m = new Mercedes();
m.brand = "Mercedes";
m.gear = "Otomatik";
m.gearType(m.brand, m.gear);

Bmw b = new Bmw();
b.brand = "Bmw";
b.gear = "Düz";
b.gearType(b.brand, b.gear);

Audi a = new Audi();
a.brand = "Audi";
a.gear = "Otomatik";
a.gearType(a.brand, a.gear);

Porsche p = new Porsche();
p.brand = "Porsche";
p.gear = "Düz";
p.gearType(p.brand, p.gear);

Toyota t = new Toyota();
t.brand = "Toyota";
t.gear = "Düz";
t.gearType(t.brand, t.gear);

Togg to = new Togg();
to.brand = "Togg";
to.gear = "Otomatik";
to.gearType(to.brand, to.gear);

